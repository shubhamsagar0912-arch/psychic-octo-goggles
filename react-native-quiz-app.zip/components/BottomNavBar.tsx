import React from 'react';
import { Screen } from '../types';
import HomeIcon from './icons/HomeIcon';
import BookOpenIcon from './icons/BookOpenIcon';
import SettingsIcon from './icons/SettingsIcon';

interface BottomNavBarProps {
  activeScreen: Screen;
  setActiveScreen: (screen: Screen) => void;
}

const NavItem: React.FC<{
    screen: Screen;
    label: string;
    Icon: React.FC<{ className?: string }>;
    isActive: boolean;
    onClick: () => void;
}> = ({ screen, label, Icon, isActive, onClick }) => {
    const activeColor = 'text-black dark:text-white';
    const inactiveColor = 'text-gray-400 group-hover:text-black dark:group-hover:text-white';
    return (
        <button
            onClick={onClick}
            className="flex flex-col items-center justify-center w-full group focus:outline-none"
        >
            <Icon className={`w-6 h-6 mb-1 transition-colors ${isActive ? activeColor : inactiveColor}`} />
            <span className={`text-xs font-medium transition-colors ${isActive ? activeColor : inactiveColor}`}>
                {label}
            </span>
        </button>
    );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeScreen, setActiveScreen }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-black border-t border-gray-200 dark:border-gray-800 max-w-md mx-auto">
      <div className="flex justify-around items-center h-full">
        <NavItem 
            screen={Screen.HOME}
            label="Home"
            Icon={HomeIcon}
            isActive={activeScreen === Screen.HOME}
            onClick={() => setActiveScreen(Screen.HOME)}
        />
        <NavItem 
            screen={Screen.LIBRARY}
            label="Library"
            Icon={BookOpenIcon}
            isActive={activeScreen === Screen.LIBRARY}
            onClick={() => setActiveScreen(Screen.LIBRARY)}
        />
        <NavItem 
            screen={Screen.SETTINGS}
            label="Settings"
            Icon={SettingsIcon}
            isActive={activeScreen === Screen.SETTINGS}
            onClick={() => setActiveScreen(Screen.SETTINGS)}
        />
      </div>
    </div>
  );
};

export default BottomNavBar;