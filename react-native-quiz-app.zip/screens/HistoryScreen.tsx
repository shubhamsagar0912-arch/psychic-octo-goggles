import React from 'react';
import { QuizAttempt } from '../types';
import ChevronLeftIcon from '../components/icons/ChevronLeftIcon';

interface HistoryScreenProps {
    history: QuizAttempt[];
    onBack: () => void;
}

const StatCard: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div className="bg-gray-100 dark:bg-gray-900 p-4 rounded-lg text-center shadow-md">
        <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
    </div>
);

const HistoryScreen: React.FC<HistoryScreenProps> = ({ history, onBack }) => {

    const totalQuizzes = history.length;
    
    const averageScore = totalQuizzes > 0 
        ? Math.round(history.reduce((acc, attempt) => acc + (attempt.score / attempt.totalQuestions), 0) / totalQuizzes * 100)
        : 0;
        
    const bestScore = totalQuizzes > 0
        ? Math.round(Math.max(...history.map(attempt => (attempt.score / attempt.totalQuestions))) * 100)
        : 0;

    return (
        <div className="p-4 text-black dark:text-white">
            <div className="flex items-center mb-6">
                 <button onClick={onBack} className="flex items-center text-black dark:text-white hover:text-gray-700 dark:hover:text-gray-300 font-semibold mr-4">
                    <ChevronLeftIcon className="w-5 h-5" />
                </button>
                <h1 className="text-3xl font-bold">Quiz History</h1>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-8">
                <StatCard label="Quizzes Taken" value={totalQuizzes.toString()} />
                <StatCard label="Average Score" value={`${averageScore}%`} />
                <StatCard label="Best Score" value={`${bestScore}%`} />
            </div>

            <h2 className="text-2xl font-semibold mb-4">All Attempts</h2>
             <div className="space-y-3 max-h-[calc(100vh-250px)] overflow-y-auto">
                    {history.length === 0 ? (
                        <p className="text-gray-500 dark:text-gray-400 text-center py-8">No quizzes taken yet.</p>
                    ) : (
                        history.map((attempt, index) => (
                            <div key={index} className="flex justify-between items-center p-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
                                <div>
                                    <p className="font-bold">{attempt.quizTitle}</p>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">
                                        {new Date(attempt.date).toLocaleString()}
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="font-semibold text-lg">
                                        {attempt.score}/{attempt.totalQuestions}
                                    </p>
                                    <p className="text-sm font-bold text-gray-600 dark:text-gray-300">
                                       {Math.round((attempt.score / attempt.totalQuestions) * 100)}%
                                    </p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
        </div>
    );
};

export default HistoryScreen;
