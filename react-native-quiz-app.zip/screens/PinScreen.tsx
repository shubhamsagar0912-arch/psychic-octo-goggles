import React, { useState, useRef, useEffect } from 'react';

interface PinScreenProps {
    onPinSuccess: () => void;
    onLogout: () => void;
    userEmail: string;
}

const PinScreen: React.FC<PinScreenProps> = ({ onPinSuccess, onLogout, userEmail }) => {
    const [pin, setPin] = useState<string[]>(['', '', '', '']);
    const [error, setError] = useState('');
    const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

    useEffect(() => {
        inputsRef.current[0]?.focus();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const { value } = e.target;
        // Allow only single digits
        if (/^[0-9]$/.test(value) || value === '') {
            const newPin = [...pin];
            newPin[index] = value;
            setPin(newPin);

            // Move focus to next input if a digit is entered
            if (value !== '' && index < 3) {
                inputsRef.current[index + 1]?.focus();
            }
            
            // If all digits are filled, automatically submit
            if (newPin.every(digit => digit !== '')) {
                 handleSubmit(newPin.join(''));
            }
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
        // Move focus to previous input on backspace if current is empty
        if (e.key === 'Backspace' && pin[index] === '' && index > 0) {
            inputsRef.current[index - 1]?.focus();
        }
    };
    
    const handleSubmit = (fullPin: string) => {
        // In this mock, we accept any 4-digit PIN.
        if (fullPin.length === 4) {
             onPinSuccess();
        } else {
            setError('Please enter a 4-digit PIN.');
            setPin(['', '', '', '']);
            inputsRef.current[0]?.focus();
        }
    };

    return (
        <div className="bg-white dark:bg-black text-black dark:text-white flex flex-col justify-center items-center p-8 h-full">
            <div className="w-full max-w-sm mx-auto text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto mb-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <h1 className="text-3xl font-serif font-bold mb-2">Enter PIN</h1>
                <p className="text-gray-500 dark:text-gray-400 mb-2">Welcome back!</p>
                <p className="font-semibold mb-8">{userEmail}</p>

                <div className="flex justify-center gap-3 sm:gap-4 mb-4">
                    {pin.map((digit, index) => (
                        <input
                            key={index}
                            // FIX: The ref callback should not return a value. Changed from an expression body to a block body.
                            ref={el => { inputsRef.current[index] = el; }}
                            type="tel"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => handleChange(e, index)}
                            onKeyDown={(e) => handleKeyDown(e, index)}
                            className="w-14 h-16 text-3xl text-center border-2 border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-black focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white"
                            aria-label={`PIN digit ${index + 1}`}
                        />
                    ))}
                </div>
                {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
                
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-8">
                  Not you?{' '}
                  <button onClick={onLogout} className="font-semibold text-black dark:text-white hover:underline focus:outline-none">
                    Log Out
                  </button>
                </p>
            </div>
        </div>
    );
};

export default PinScreen;