import React from 'react';
import LoginIcon from '../components/icons/LoginIcon';
import GoogleIcon from '../components/icons/GoogleIcon';

interface LoginScreenProps {
  onLogin: () => void;
  onGoToSignUp: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGoToSignUp }) => {
  return (
    <div className="bg-white dark:bg-black text-black dark:text-white flex flex-col justify-center p-8 h-full">
      <div className="w-full max-w-sm mx-auto">
        <div className="flex justify-center mb-6">
          <LoginIcon className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-serif font-bold text-center mb-2">Welcome Back</h1>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-8">
          Sign in to access your quizzes and track your progress
        </p>

        <form onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1" htmlFor="email">
              Email or Phone
            </label>
            <input
              type="text"
              id="email"
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-black focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white"
              placeholder="Enter your email or phone"
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-black focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white"
              placeholder="Enter your password"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-black dark:bg-white text-white dark:text-black font-semibold py-3 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors"
          >
            Log In
          </button>
        </form>

        <div className="flex items-center my-6">
          <div className="flex-grow border-t border-gray-300 dark:border-gray-700"></div>
          <span className="flex-shrink mx-4 text-gray-500 dark:text-gray-400 text-sm">OR</span>
          <div className="flex-grow border-t border-gray-300 dark:border-gray-700"></div>
        </div>

        <button className="w-full flex items-center justify-center py-3 border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-900 transition-colors">
          <GoogleIcon className="w-6 h-6 mr-3" />
          <span className="font-semibold">Continue with Google</span>
        </button>

        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-8">
          Don't have an account?{' '}
          <button onClick={onGoToSignUp} className="font-semibold text-black dark:text-white hover:underline focus:outline-none">
            Sign Up
          </button>
        </p>
        
        <p className="text-center text-xs text-gray-400 dark:text-gray-500 mt-12">
            By continuing, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;
