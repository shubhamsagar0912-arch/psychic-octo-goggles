import React, { useState, useEffect } from 'react';
import { Quiz, Answer, SavedQuizState } from '../types';

interface QuizScreenProps {
  quiz: Quiz;
  onComplete: (score: number) => void;
  savedState: SavedQuizState | null;
}

const ClockIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const QuizScreen: React.FC<QuizScreenProps> = ({ quiz, onComplete, savedState }) => {
  const initialState = savedState && savedState.quizId === quiz.id ? savedState : null;

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(initialState?.currentQuestionIndex ?? 0);
  const [selectedAnswer, setSelectedAnswer] = useState<Answer | null>(null);
  const [score, setScore] = useState(initialState?.score ?? 0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(initialState?.timeLeft ?? quiz.timeLimit);

  useEffect(() => {
    // Only save progress for timed quizzes
    if (quiz.timeLimit !== undefined && timeLeft !== undefined) {
      const progress: SavedQuizState = {
        quizId: quiz.id,
        currentQuestionIndex,
        score,
        timeLeft,
      };
      localStorage.setItem('savedQuizProgress', JSON.stringify(progress));
    }
  }, [quiz.id, quiz.timeLimit, currentQuestionIndex, score, timeLeft]);

  useEffect(() => {
    if (timeLeft === undefined) return;

    if (timeLeft <= 0) {
      // Defer completion to next tick to avoid state update issues
      setTimeout(() => onComplete(score), 0);
      return;
    }

    const timerId = setInterval(() => {
      setTimeLeft((prevTime) => (prevTime ? prevTime - 1 : 0));
    }, 1000);

    return () => clearInterval(timerId);
  }, [timeLeft, onComplete, score]);

  const currentQuestion = quiz.questions[currentQuestionIndex];

  const handleAnswerClick = (answer: Answer) => {
    if (isAnswered) return;

    setSelectedAnswer(answer);
    setIsAnswered(true);
    if (answer.isCorrect) {
      setScore(score + 1);
    }
  };

  const handleNextClick = () => {
    setIsAnswered(false);
    setSelectedAnswer(null);

    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      onComplete(score);
    }
  };

  const getButtonClass = (answer: Answer) => {
    if (!isAnswered) {
      return 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-900 dark:hover:bg-gray-800';
    }
    if (answer.isCorrect) {
      return 'bg-green-500 text-white';
    }
    if (answer === selectedAnswer && !answer.isCorrect) {
      return 'bg-red-500 text-white';
    }
    return 'bg-gray-100 dark:bg-gray-900 opacity-60';
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-6 text-black dark:text-white flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <p className="font-semibold">Question {currentQuestionIndex + 1} of {quiz.questions.length}</p>
        {timeLeft !== undefined && (
            <div className={`flex items-center font-bold text-lg px-3 py-1 rounded-full ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-gray-500 dark:text-gray-300'}`}>
                <ClockIcon className="w-5 h-5 mr-2" />
                {formatTime(timeLeft)}
            </div>
        )}
      </div>
      <h1 className="text-2xl font-bold mb-4">{currentQuestion.questionText}</h1>
      
      <div className="space-y-4 flex-grow">
        {currentQuestion.answers.map((answer, index) => (
          <button
            key={index}
            onClick={() => handleAnswerClick(answer)}
            disabled={isAnswered}
            className={`w-full text-left p-4 rounded-lg transition-all duration-300 ${getButtonClass(answer)}`}
          >
            {answer.text}
          </button>
        ))}
      </div>
      {isAnswered && (
        <button
          onClick={handleNextClick}
          className="w-full mt-6 py-3 bg-black text-white dark:bg-white dark:text-black font-semibold rounded-lg shadow-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-all transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white focus:ring-opacity-50"
        >
          {currentQuestionIndex < quiz.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
        </button>
      )}
    </div>
  );
};

export default QuizScreen;
