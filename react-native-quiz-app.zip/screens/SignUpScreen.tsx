import React from 'react';
import GoogleIcon from '../components/icons/GoogleIcon';

interface SignUpScreenProps {
  onSignUp: () => void;
  onGoToLogin: () => void;
}

const SignUpScreen: React.FC<SignUpScreenProps> = ({ onSignUp, onGoToLogin }) => {
  return (
    <div className="bg-white dark:bg-black text-black dark:text-white flex flex-col justify-center p-8 h-full">
      <div className="w-full max-w-sm mx-auto">
        <div className="flex justify-center mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
            </svg>
        </div>
        <h1 className="text-3xl font-serif font-bold text-center mb-2">Create Account</h1>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-8">
          Let's get you started with your quiz journey!
        </p>

        <form onSubmit={(e) => { e.preventDefault(); onSignUp(); }}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1" htmlFor="email">
              Email
            </label>
            <input
              type="email"
              id="email"
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-black focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white"
              placeholder="Enter your email"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-black focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white"
              placeholder="Create a password"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-black dark:bg-white text-white dark:text-black font-semibold py-3 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors mt-2"
          >
            Sign Up
          </button>
        </form>

        <div className="flex items-center my-6">
          <div className="flex-grow border-t border-gray-300 dark:border-gray-700"></div>
          <span className="flex-shrink mx-4 text-gray-500 dark:text-gray-400 text-sm">OR</span>
          <div className="flex-grow border-t border-gray-300 dark:border-gray-700"></div>
        </div>

        <button className="w-full flex items-center justify-center py-3 border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-900 transition-colors">
          <GoogleIcon className="w-6 h-6 mr-3" />
          <span className="font-semibold">Sign up with Google</span>
        </button>

        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-8">
          Already have an account?{' '}
          <button onClick={onGoToLogin} className="font-semibold text-black dark:text-white hover:underline focus:outline-none">
            Log In
          </button>
        </p>
      </div>
    </div>
  );
};

export default SignUpScreen;
