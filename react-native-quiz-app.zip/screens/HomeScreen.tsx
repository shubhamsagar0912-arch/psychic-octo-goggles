import React from 'react';
import { Screen, QuizAttempt, Quiz } from '../types';
import { SUBJECTS } from '../constants';
import BookOpenIcon from '../components/icons/BookOpenIcon';
import PlusIcon from '../components/icons/PlusIcon';
import SparklesIcon from '../components/icons/SparklesIcon';
import ChevronRightIcon from '../components/icons/ChevronRightIcon';

interface HomeScreenProps {
  setActiveScreen: (screen: Screen) => void;
  history: QuizAttempt[];
  onQuizSelect: (quiz: Quiz) => void;
}

const StatCard: React.FC<{ label: string; value: string | number; subtext?: string; fullWidth?: boolean }> = ({ label, value, subtext, fullWidth }) => (
    <div className={`bg-white dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-800 ${fullWidth ? 'col-span-2' : ''}`}>
        <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
        <p className="text-3xl font-bold mt-1">{value}</p>
        {subtext && <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{subtext}</p>}
    </div>
);

const HomeScreen: React.FC<HomeScreenProps> = ({ setActiveScreen, history, onQuizSelect }) => {
    const totalQuizzes = SUBJECTS.reduce((sum, subject) => sum + subject.quizzes.length, 0);
    const totalSubjects = SUBJECTS.length;
    const totalAttempts = history.length;
    
    const averageScore = totalAttempts > 0 
        ? Math.round(history.reduce((acc, attempt) => acc + (attempt.score / attempt.totalQuestions), 0) / totalAttempts * 100)
        : 0;

    const recentQuizzes = history.slice(0, 2).map(attempt => {
        const quiz = SUBJECTS.flatMap(s => s.quizzes).find(q => q.id === attempt.quizId);
        return quiz;
    }).filter((quiz): quiz is Quiz => quiz !== undefined);

  return (
    <div className="p-6 text-black dark:text-white">
        <h1 className="text-4xl font-serif font-bold">MBBS Q</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1 mb-6">Master your medical knowledge</p>

        <div className="grid grid-cols-2 gap-4 mb-8">
            <StatCard label="Total Quizzes" value={totalQuizzes} subtext={`${totalSubjects} subjects`} />
            <StatCard label="Attempts" value={totalAttempts} />
            <StatCard label="Avg Score" value={`${averageScore}%`} fullWidth />
        </div>

        <h2 className="text-xl font-bold font-serif mb-3">Quick Actions</h2>
        <div className="space-y-3 mb-8">
            <button 
                onClick={() => setActiveScreen(Screen.LIBRARY)}
                className="w-full flex items-center text-left bg-black dark:bg-white text-white dark:text-black p-4 rounded-xl"
            >
                <BookOpenIcon className="w-6 h-6 mr-4" />
                <div>
                    <p className="font-semibold">Browse Library</p>
                    <p className="text-sm text-gray-300 dark:text-gray-500">Explore {totalQuizzes} quizzes across {totalSubjects} subjects</p>
                </div>
            </button>
            <div className="grid grid-cols-2 gap-3">
                <button className="w-full flex items-center justify-center bg-white dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-800">
                    <PlusIcon className="w-5 h-5 mr-2" />
                    <span className="font-semibold">Create Quiz</span>
                </button>
                <button className="w-full flex items-center justify-center bg-white dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-800">
                    <SparklesIcon className="w-5 h-5 mr-2" />
                    <span className="font-semibold">AI Generate</span>
                </button>
            </div>
        </div>

        <h2 className="text-xl font-bold font-serif mb-3">Recent Quizzes</h2>
        <div className="space-y-3">
            {recentQuizzes.length > 0 ? (
                recentQuizzes.map(quiz => (
                    <button 
                        key={quiz.id}
                        onClick={() => onQuizSelect(quiz)}
                        className="w-full flex justify-between items-center text-left bg-white dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-800"
                    >
                        <div>
                            <p className="font-semibold">{quiz.title}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{quiz.questions.length} questions</p>
                        </div>
                        <ChevronRightIcon className="w-5 h-5 text-gray-400" />
                    </button>
                ))
            ) : (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-900/50 rounded-xl border border-gray-200 dark:border-gray-800">
                    <p>No recent quizzes.</p>
                    <p className="text-sm">Take a quiz from the library to start!</p>
                </div>
            )}
        </div>
    </div>
  );
};

export default HomeScreen;