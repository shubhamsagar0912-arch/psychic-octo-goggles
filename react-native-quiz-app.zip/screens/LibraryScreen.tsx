import React, { useState } from 'react';
import { Subject, Quiz } from '../types';
import { SUBJECTS } from '../constants';
import ChevronLeftIcon from '../components/icons/ChevronLeftIcon';

interface LibraryScreenProps {
  onQuizSelect: (quiz: Quiz) => void;
}

const LibraryScreen: React.FC<LibraryScreenProps> = ({ onQuizSelect }) => {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);

  if (selectedSubject) {
    return (
      <div className="p-4 text-black dark:text-white">
        <button onClick={() => setSelectedSubject(null)} className="flex items-center text-black dark:text-white hover:text-gray-700 dark:hover:text-gray-300 mb-4 font-semibold">
          <ChevronLeftIcon className="w-5 h-5 mr-2" />
          Back to Library
        </button>
        <h1 className="text-3xl font-bold mb-6 flex items-center">
            <selectedSubject.icon className="w-8 h-8 mr-3 text-black dark:text-white" />
            {selectedSubject.name}
        </h1>
        <div className="space-y-4">
          {selectedSubject.quizzes.map((quiz) => (
            <div
              key={quiz.id}
              onClick={() => onQuizSelect(quiz)}
              className="bg-gray-100 dark:bg-gray-900 p-5 rounded-lg cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors shadow-lg"
            >
              <h2 className="text-xl font-semibold">{quiz.title}</h2>
              <p className="text-gray-500 dark:text-gray-400">{quiz.questions.length} questions</p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 text-black dark:text-white">
      <h1 className="text-3xl font-bold mb-6">Choose a Subject</h1>
      <div className="grid grid-cols-2 gap-4">
        {SUBJECTS.map((subject) => (
          <div
            key={subject.id}
            onClick={() => setSelectedSubject(subject)}
            className="bg-gray-100 dark:bg-gray-900 p-5 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-800 transition-all transform hover:scale-105 shadow-lg"
          >
            <subject.icon className="w-12 h-12 mb-3 text-black dark:text-white" />
            <h2 className="text-lg font-semibold text-center">{subject.name}</h2>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LibraryScreen;