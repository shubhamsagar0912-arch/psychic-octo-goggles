
import React from 'react';

interface ResultsScreenProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
  onGoToSubjects: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ score, totalQuestions, onRestart, onGoToSubjects }) => {
  const percentage = Math.round((score / totalQuestions) * 100);
  let message = '';
  if (percentage === 100) {
    message = 'Perfect Score! Incredible!';
  } else if (percentage >= 75) {
    message = 'Great job! You really know your stuff.';
  } else if (percentage >= 50) {
    message = 'Not bad! A little more practice will help.';
  } else {
    message = 'Keep trying! Practice makes perfect.';
  }

  return (
    <div className="p-6 text-black dark:text-white flex flex-col items-center text-center h-full justify-center">
      <h1 className="text-4xl font-bold mb-2">Quiz Complete!</h1>
      <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">You scored</p>
      <div className="text-6xl font-extrabold text-black dark:text-white mb-2">{score} / {totalQuestions}</div>
      <p className="text-2xl font-semibold text-gray-600 dark:text-gray-300 mb-6">({percentage}%)</p>
      <p className="text-xl text-gray-700 dark:text-gray-200 mb-10">{message}</p>
      <div className="flex flex-col w-full max-w-xs space-y-4">
        <button
          onClick={onRestart}
          className="w-full py-3 bg-black text-white dark:bg-white dark:text-black font-semibold rounded-lg shadow-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-all transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white focus:ring-opacity-50"
        >
          Try Again
        </button>
        <button
          onClick={onGoToSubjects}
          className="w-full py-3 bg-gray-200 text-black hover:bg-gray-300 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700 font-semibold rounded-lg shadow-lg transition-all focus:outline-none"
        >
          Choose Another Subject
        </button>
      </div>
    </div>
  );
};

export default ResultsScreen;