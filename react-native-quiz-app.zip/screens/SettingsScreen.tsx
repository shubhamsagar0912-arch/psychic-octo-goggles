import React, { useState, useEffect } from 'react';
import { QuizAttempt, UserProfile } from '../types';
import { COUNTRIES } from '../countries';
import ChevronRightIcon from '../components/icons/ChevronRightIcon';

const YEARS = ['1st', '2nd', '3rd', '4th Professionals'];

interface SettingsScreenProps {
    history: QuizAttempt[];
    onClearHistory: () => void;
    onViewHistory: () => void;
    profile: UserProfile;
    onUpdateProfile: (profile: UserProfile) => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ history, onClearHistory, onViewHistory, profile, onUpdateProfile }) => {
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [isEditingProfile, setIsEditingProfile] = useState(false);
    const [editableProfile, setEditableProfile] = useState<UserProfile>(profile);
    
    useEffect(() => {
        setEditableProfile(profile);
    }, [profile]);

    useEffect(() => {
        const isDark = document.documentElement.classList.contains('dark');
        setIsDarkMode(isDark);
    }, []);

    const toggleDarkMode = () => {
        if (isDarkMode) {
            document.documentElement.classList.remove('dark');
        } else {
            document.documentElement.classList.add('dark');
        }
        setIsDarkMode(!isDarkMode);
    };
    
    const handleClearHistory = () => {
        if (window.confirm('Are you sure you want to clear all quiz history? This action cannot be undone.')) {
            onClearHistory();
        }
    };

    const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setEditableProfile(prev => ({ ...prev, [name]: value }));
    };

    const handleSaveProfile = () => {
        onUpdateProfile(editableProfile);
        setIsEditingProfile(false);
    };
    
    const handleCancelEdit = () => {
        setEditableProfile(profile);
        setIsEditingProfile(false);
    }

    const commonInputClass = "w-full text-lg bg-transparent text-black dark:text-white p-1 -ml-1 focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white rounded";

    return (
        <div className="p-6 text-black dark:text-white">
            <h1 className="text-3xl font-bold mb-8">Settings</h1>
            
            {/* User Profile Section */}
            <div className="mb-6 bg-gray-100 dark:bg-gray-900 p-4 rounded-lg shadow-md">
                 <div className="flex justify-between items-center mb-2">
                    <h2 className="font-semibold text-lg">User Profile</h2>
                    <div>
                        {isEditingProfile && (
                             <button
                                onClick={handleCancelEdit}
                                className="text-sm font-semibold text-gray-500 hover:text-gray-700 dark:hover:text-gray-400 focus:outline-none mr-4"
                            >
                                Cancel
                            </button>
                        )}
                        <button
                            onClick={isEditingProfile ? handleSaveProfile : () => setIsEditingProfile(true)}
                            className="text-sm font-semibold text-black dark:text-white hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none"
                        >
                            {isEditingProfile ? 'Save' : 'Edit'}
                        </button>
                    </div>
                </div>
                {/* Name */}
                <div className="py-3 border-b border-gray-200 dark:border-gray-800">
                    <label htmlFor="name" className="text-sm text-gray-500 dark:text-gray-400">Name</label>
                    {isEditingProfile ? <input id="name" type="text" name="name" value={editableProfile.name} onChange={handleProfileChange} className={commonInputClass} placeholder="Enter your name" /> : <p className="text-lg font-semibold">{profile.name || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
                {/* Email */}
                <div className="py-3 border-b border-gray-200 dark:border-gray-800">
                    <label htmlFor="email" className="text-sm text-gray-500 dark:text-gray-400">Email</label>
                    {isEditingProfile ? <input id="email" type="email" name="email" value={editableProfile.email} onChange={handleProfileChange} className={commonInputClass} placeholder="Enter your email" /> : <p className="text-lg font-semibold">{profile.email || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
                {/* Phone */}
                <div className="py-3 border-b border-gray-200 dark:border-gray-800">
                    <label htmlFor="phone" className="text-sm text-gray-500 dark:text-gray-400">Phone</label>
                    {isEditingProfile ? <input id="phone" type="tel" pattern="[0-9]*" name="phone" value={editableProfile.phone} onChange={handleProfileChange} className={commonInputClass} placeholder="Enter your phone" /> : <p className="text-lg font-semibold">{profile.phone || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
                {/* Year */}
                <div className="py-3 border-b border-gray-200 dark:border-gray-800">
                    <label htmlFor="year" className="text-sm text-gray-500 dark:text-gray-400">Year</label>
                    {isEditingProfile ? (
                        <select id="year" name="year" value={editableProfile.year} onChange={handleProfileChange} className={`${commonInputClass} appearance-none`}>
                            <option value="">Select Year</option>
                            {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                    ) : <p className="text-lg font-semibold">{profile.year || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
                 {/* College */}
                <div className="py-3 border-b border-gray-200 dark:border-gray-800">
                    <label htmlFor="college" className="text-sm text-gray-500 dark:text-gray-400">College</label>
                    {isEditingProfile ? <input id="college" type="text" name="college" value={editableProfile.college} onChange={handleProfileChange} className={commonInputClass} placeholder="Enter your college" /> : <p className="text-lg font-semibold">{profile.college || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
                {/* Country */}
                <div className="py-3">
                    <label htmlFor="country" className="text-sm text-gray-500 dark:text-gray-400">Country</label>
                    {isEditingProfile ? (
                        <select id="country" name="country" value={editableProfile.country} onChange={handleProfileChange} className={`${commonInputClass} appearance-none`}>
                            <option value="">Select Country</option>
                            {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    ) : <p className="text-lg font-semibold">{profile.country || <span className="text-gray-400 dark:text-gray-500">Not set</span>}</p>}
                </div>
            </div>

            {/* Dark Mode Toggle */}
            <div className="bg-gray-100 dark:bg-gray-900 p-4 rounded-lg shadow-md">
                <div className="flex justify-between items-center">
                    <span className="font-semibold text-lg">Dark Mode</span>
                    <button
                        onClick={toggleDarkMode}
                        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black dark:focus:ring-white dark:focus:ring-offset-gray-900 ${
                            isDarkMode ? 'bg-white' : 'bg-gray-400'
                        }`}
                    >
                        <span
                            className={`inline-block w-4 h-4 transform bg-white dark:bg-black rounded-full transition-transform duration-300 ${
                                isDarkMode ? 'translate-x-6' : 'translate-x-1'
                            }`}
                        />
                    </button>
                </div>
            </div>

            {/* Quiz History Section */}
            <div className="mt-6 bg-gray-100 dark:bg-gray-900 p-4 rounded-lg shadow-md">
                 <div className="flex justify-between items-center mb-2">
                    <h2 className="font-semibold text-lg">Quiz History</h2>
                    {history.length > 0 && (
                        <button
                            onClick={handleClearHistory}
                            className="text-sm font-semibold text-red-500 hover:text-red-700 dark:hover:text-red-400 focus:outline-none"
                        >
                            Clear History
                        </button>
                    )}
                </div>
                <button 
                    onClick={onViewHistory}
                    className="w-full flex justify-between items-center p-3 bg-white dark:bg-gray-800 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    aria-label="View quiz history and statistics"
                >
                    <div>
                        <p className="font-semibold">View Statistics</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                            You've taken {history.length} {history.length === 1 ? 'quiz' : 'quizzes'}.
                        </p>
                    </div>
                    <ChevronRightIcon className="w-5 h-5 text-gray-400" />
                </button>
            </div>

            {/* About Section */}
            <div className="mt-6 bg-gray-100 dark:bg-gray-900 p-4 rounded-lg shadow-md">
                <h2 className="font-semibold text-lg mb-2">About</h2>
                <p className="text-gray-600 dark:text-gray-400">
                    Quiz App v1.0.0
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                    Made with React & Tailwind CSS.
                </p>
            </div>
        </div>
    );
};

export default SettingsScreen;